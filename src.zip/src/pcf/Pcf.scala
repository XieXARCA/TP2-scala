package pcf

import parser.AbstractParser.analyze
import evaluator.Evaluator.eval
import ast.Value.toInt

import java.io.{FileInputStream, InputStream}

object Pcf:
  def main(args: Array[String]): Unit =
    val in: InputStream =
      if args.isEmpty then
        System.in
      else
        FileInputStream(args(0))
        
    val term = analyze(in)
    println(s"==> ${toInt(eval(term, Map()))}")



